import React from "react";

const MarketingFaqs = () => {
  return <div>MarketingFaqs</div>;
};

export default MarketingFaqs;
